from data_loader import load_df, load_testset
from vgg_model import createModel #"model" for our own model, "vgg_model" for vgg
from training_generator import init_data_generators
from predictor import accuracy, prediction_plot, regression_plot, plot_confusion_matrix

import matplotlib.pyplot as plt
import tensorflow as tf
import keras


#------------------Parameters--------------------------------
image_shape = (384,384,3) # 1 channel for own model, 3 channels for vgg
csv_path = 'boneage-training-dataset.csv'
data_path = '/work/simentha/corrected-boneage-training-dataset'
path_col = 'path'
target_col = 'boneage'

#-------------------Load data--------------------------------
train_df, val_df, test_df = load_df(csv_path, data_path)

#------------------Hyperparameters-------------------
epochs = 30
train_batch_size = 32
val_batch_size = 16
learning_rate = 3e-03
weigth_decay = 0

#-------------------Training tools-------------------
opt = keras.optimizers.Adam(lr=learning_rate, decay=weigth_decay)
loss = keras.losses.MSE

early_stopping = keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)
annealing_rate = keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.7, patience=2, min_lr=0.001)

callbacks_list = [early_stopping, annealing_rate]

#--------------Initialize datagenerator and model-------------------
train_gen, val_gen = init_data_generators(train_df,val_df, path_col, target_col, image_shape, train_batch_size, val_batch_size)

model = createModel(opt, loss, image_shape)

#--------------------Training-------------------------
history = model.fit_generator(train_gen,
			      validation_data=val_gen,
                   	      steps_per_epoch=train_gen.n // train_gen.batch_size,
                    	      validation_steps=val_gen.n // val_gen.batch_size,
                    	      epochs = epochs, 
                    	      callbacks = callbacks_list)
print(30*"-" + "Training finished" + 30*"-")

model.save('selfmade_model.h5')

#--------------Plot training history-------------------
# mean average error in age prediction
plt.plot(history.history['mae_months'])
plt.plot(history.history['val_mae_months'])
plt.ylim([0, 100])
plt.title('Mean absolute error')
plt.ylabel('MAE [months]')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
plt.savefig('Figures/mean_absolute_error.png')
plt.close()

# loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.ylim([0, 5000])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
plt.savefig('Figures/loss.png')
plt.close()

#---------------Predict on test set------------------
test_data, test_labels = load_testset(test_df, path_col, target_col, image_shape)

prediction_plot(model, test_data, test_labels)
regression_plot(model, test_data, test_labels)
plot_confusion_matrix(model, test_data, test_labels)
accuracy(model, test_data, test_labels)

