import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

from skimage.io import imread
from sklearn.model_selection import train_test_split
from keras.preprocessing.image import ImageDataGenerator
from keras.applications.vgg16 import preprocess_input

def load_df(csv_path, data_path):
    """
    Loads dataframes which is utilized in the data_generators. 
    Also saves plot of the raw data distribution and the 
    balanced data distribution in the "Figures" folder.  

    Input: Paths (strings) for the csv file and the training data
    Output: Dataframes for test, validation and test sets
    """
    #--------------------Read in data from CSV----------------------------
    age_df = pd.read_csv(csv_path)
    age_df['path'] = age_df['id'].map(lambda x: os.path.join(data_path,
                                                            '{}.png'.format(x)))
    age_df['exists'] = age_df['path'].map(os.path.exists)
    print(age_df['exists'].sum(), 'images found of', age_df.shape[0], 'total')
    age_df['boneage_category'] = pd.cut(age_df['boneage'], 50)
    age_df.dropna(inplace=True)

    # Plot distribution
    hist= age_df['boneage'].hist(figsize=(10,5))
    plt.title('Age distribution for training data')
    plt.xlabel('Age category [months]')
    plt.ylabel('# of data points')
    hist = hist.get_figure()
    hist.savefig('Figures/raw_distribution.png')
    plt.close()

    #---------------------Split and balance data---------------------------
    train_df, valid_df = train_test_split(age_df, test_size=0.25)
    valid_df, test_df = train_test_split(valid_df, test_size =0.4)
    print('train', train_df.shape[0], 'validation', valid_df.shape[0], 'test', test_df.shape[0])

    old_size = train_df.shape[0]
    train_df = train_df.groupby(['boneage_category', 'male']).apply(lambda x: x.sample(1000, replace=True))

    print('New Data Size:', train_df.shape[0], 'Old:', old_size)
    
    # Plot balanced distribution
    hist = train_df['boneage'].hist(figsize=(10,5))
    plt.title('New age distribution for training data')
    plt.xlabel('Age category')
    plt.ylabel('# of data points')
    hist = hist.get_figure()
    hist.savefig('Figures/data_distribution.png')
    plt.close()

    return train_df, valid_df, test_df

def load_testset(test_df, path_col, target_col, in_shape):
    """
    Loads data (images) and labels from the test dataframe. Note that this data
    is previously unseen for the model. 

    Input: test dataframe, **df_args (see keras.io for **df_args documentation)
    Output: test data (images) and test labels
    """
    color = 'rgb' if in_shape[2] == 3 else 'grayscale'
    preprocessing = preprocess_input if in_shape[2] == 3 else None
    img_size = in_shape[0:2]

    datasize = test_df['boneage'].shape[0]
    test_datagen = ImageDataGenerator(preprocessing_function=preprocessing)
    test_generator = test_datagen.flow_from_dataframe(test_df,
                                                        x_col=path_col,
                                                        y_col=target_col,
                                                        class_mode='other',
                                                        target_size=img_size,
                                                        color_mode=color,
                                                        batch_size=datasize)
    test_data, test_labels = next(test_generator)

    return test_data, test_labels
