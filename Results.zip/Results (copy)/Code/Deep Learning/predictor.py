import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

from pandas_ml import ConfusionMatrix
from skimage.io import imread
from sklearn.model_selection import train_test_split

"""
All methods in this script takes in a keras.Model instance, test-data images, and test-data labels
and returns a form for performance score (plots or values). 
"""

def prediction_plot(model, test_data, test_labels):
    '''
    Plots 8 samples togheter with the respective labels and predictions. Saves the figure
    in the "Figures" folder.
    '''
    pred = model.predict(test_data, batch_size=32)

    ord_idx = np.argsort(test_labels)
    ord_idx = ord_idx[np.linspace(0, len(ord_idx)-1, 8).astype(int)]
    
    # plot predicted samples 
    fig, m_axs = plt.subplots(4, 2, figsize = (16, 32))
    for (idx, c_ax) in zip(ord_idx, m_axs.flatten()):
        c_ax.imshow(test_data[idx, :,:,0], cmap = 'bone')
    
        c_ax.set_title('Age: %2.1fY\nPredicted Age: %2.1fY' % (test_labels[idx]/12.0, 
                                                           pred[idx]/12.0))
        c_ax.axis('off')
    fig.savefig('Figures/trained_img_predictions.png')
    plt.close()

def accuracy(model, test_data, test_labels):
    """
    Tests the models accuracy and prints the result.
    """
    datasize = test_labels.shape[0]
    correct = 0
    print(30*"-" + f"Calculating accuracy on {datasize} unseen images" + 30*"-")
    for i in range(datasize):
        img = test_data[i]
        img = np.expand_dims(img, axis=0)
        label = test_labels[i]
        pred = model.predict(img, batch_size=1)
        if abs(label-pred) <= 12:
            correct += 1
    
    print('Accuracy for model was: ', correct/datasize)

def regression_plot(model, test_data, test_labels):
    """
    Plots a regression line and scatter plots the predictions around this line.
    Saves the figure in the "Figures" folder.
    """
    pred = model.predict(test_data, batch_size=32)

    fig, ax1 = plt.subplots(1,1, figsize = (6,6))
    ax1.plot(test_labels, pred, 'r.', label = 'predictions')
    ax1.plot(test_labels, test_labels, 'b-', label = 'actual')
    ax1.legend()
    ax1.set_xlabel('Actual Age (Months)')
    ax1.set_ylabel('Predicted Age (Months)')
    fig.savefig('Figures/regression_plot.png')
    plt.close()

def plot_confusion_matrix(model, test_data, test_labels):
    """
    Plots a confusion matrix
    Saves the figure in the "Figures" folder.
    """
    pred = model.predict(test_data, batch_size=32)
    pred = np.max(pred, axis=1)

    test_labels = test_labels // 12
    pred = pred // 12

    cm = ConfusionMatrix(test_labels, pred)
    cm.plot()
    plt.show()
    plt.savefig('Figures/confusion_matrix.png')
    plt.close()
