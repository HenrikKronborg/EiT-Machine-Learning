
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from keras.preprocessing.image import ImageDataGenerator
from keras.applications.vgg16 import preprocess_input

def init_data_generators(train_df, val_df, path_col, target_col, in_shape, train_batch_size, val_batch_size):
    """ 
    Initiatlizes the data_generators which is used to load the data batch by batch while training.
    This makes sure that the computer don't run out of memory. However, if the computer returns 
    memory error, train_batch_size and val_batch_size must be reduced. This function also 
    saves a figure with 8 image samples and their corresponding label in the "Figures" folder. 

    Input: Dataframes, **df_args (see keras.io for **df_args documentation)
    Output: Datagenerators for train and validation data, respectively.  
    """
    color = 'rgb' if in_shape[2] == 3 else 'grayscale'
    preprocessing = preprocess_input if in_shape[2] == 3 else None
    img_size = in_shape[0:2]

    train_datagen = ImageDataGenerator(samplewise_center=False,
                            samplewise_std_normalization=False,
                            horizontal_flip=True,
                            vertical_flip=False,
                            height_shift_range=0.15,
                            width_shift_range=0.15,
                            rotation_range=5,
                            shear_range=0.01,
                            fill_mode='nearest',
                            zoom_range=0.25,
                            preprocessing_function=preprocessing)                                           
    
    val_datagen = ImageDataGenerator(preprocessing_function=preprocessing)

    train_generator = train_datagen.flow_from_dataframe(train_df,
                                                        x_col=path_col,
                                                        y_col=target_col,
                                                        class_mode='other',
                                                        target_size=img_size,
                                                        color_mode=color,
                                                        batch_size=train_batch_size)

    val_generator = val_datagen.flow_from_dataframe(val_df,
                                                        x_col=path_col,
                                                        y_col=target_col,
                                                        class_mode='other',
                                                        target_size=img_size,
                                                        color_mode=color,
                                                        batch_size=val_batch_size)

    # plot example figures from validation data
    t_x, t_y = next(val_generator)
    fig, m_axs = plt.subplots(2, 4, figsize = (16, 8))
    for (c_x, c_y, c_ax) in zip(t_x, t_y, m_axs.flatten()):
        c_ax.imshow(c_x[:,:,0], cmap = 'bone', vmin = -127, vmax = 127)
        c_ax.set_title('%2.0f months' % (c_y))
        c_ax.axis('off')
    fig.savefig('Figures/sample_data')
    plt.close()

    return train_generator, val_generator


