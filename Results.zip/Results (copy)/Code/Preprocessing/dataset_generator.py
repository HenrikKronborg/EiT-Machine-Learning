from pathlib import Path
from image_reader import ARRAY_FROM_PATH, SIMPLE_ARRAY_FROM_PATH
from image_reader import MAX_HEIGHT, MAX_WIDTH
import csv
import numpy as np
import matplotlib.pyplot as plt


# --- Parameters -------------------------------------------------------------

TRAINING_DIR     = Path("/work/simentha/boneage-training-dataset")
TEST_DIR         = Path("test-dataset")
SAMPLES_METADATA = Path("boneage-training-dataset.csv")
GENERATED_DIR    = Path("/work/simentha/corrected-boneage-training-dataset")
ARRAY_CREATOR    = ARRAY_FROM_PATH

# ----------------------------------------------------------------------------

# Go through the csv file and complete the dictionary maps
with open(SAMPLES_METADATA, mode='r') as csv_file:
    csv_data = csv.reader(csv_file, delimiter=',')
    
    # The first line is the header, which we ignore
    csv_data.__next__()
    
    # Fetch the data
    data = [(id_, int(age), is_male=="True") for id_, age, is_male in csv_data]
    
    # Transpose the dataset
    ids, ages, is_males = zip(*data)
    

# id->age mapping
id_age = {id_: age for id_, age in zip(ids, ages)}

def obtain_data(data_path, id_label):
    # Objects in dataset
    obj_count = sum(1 for obj in data_path.iterdir())
    
    # Initialize numpy array (3-tensor) for the training arrays & age labels
    dataset = np.empty((obj_count, MAX_HEIGHT, MAX_WIDTH))
    label = np.empty(obj_count)
    for i, image_file in enumerate(data_path.iterdir()):
        print(f"Reading file {i+1} of {obj_count}.")
        
        # gets array from image path
        image = ARRAY_CREATOR(image_file.__str__())
        image.save(f"{GENERATED_DIR}/{image_file.stem}.png")
        
        # gets label from id (file name)
        label[i] = id_label[image_file.stem]
    
    return dataset, label

# Iterate through the training set folder and add to image_arrays
training_arrays, training_age = obtain_data(TRAINING_DIR, id_age)

# Iterate through the training set folder and add to image_arrays
test_arrays, test_age = obtain_data(TEST_DIR, id_age)

# Pickle file names and their objects
file_object = {
    "training_set"    : training_arrays,
    "training_labels" : training_age,
    "test_set"        : test_arrays,
    "test_labels"     : test_age,
}

# Pickle dump the image arrays
for file, obj in file_object.items():
    with open(GENERATED_DIR / f"{file}.npy", mode='wb') as pickle_file:
        print(f"Writing {file}.P.")
        np.save(pickle_file, obj)

if __name__ == "__main__":
    mean_image = np.mean(training_arrays, axis=0)
    plt.imshow(mean_image); plt.show()
